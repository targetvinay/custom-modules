# -*- coding: utf-8 -*-
{
    'name': "Service Order",
    'price': '159.00',
    'currency':'EUR',
    'description': """This module helps to keep track of services and invoicing them accordingly.""",
    'author': "Target Integration",
    'website': "http://www.targetintegration.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['sale', 'account', 'web_digital_sign', 'helpdesk'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/ti_service_views.xml',
        'data/ir_sequence_data.xml',
        'views/ti_service_report.xml',
        'views/helpdesk_views.xml',
    ],
     'images': [
         'static/description/service_banner.jpeg',
     ],
    'application': True,
    'live_test_url':'https://www.targetintegration.com/openerp',
}
