# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from datetime import date
from datetime import time
from datetime import datetime


class TiService(models.Model):
    _name = 'ti.service'
    _description = 'Service'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char('Code', copy=False, default=lambda self: _('New'), readonly=True)
    partner_id = fields.Many2one('res.partner', 'Customer', index=True, help='customer.field.help.text')
    fees_lines_ids = fields.One2many('service.fee', 'service_id', 'Fees', copy=True, readonly=True)
    pricelist_id = fields.Many2one('product.pricelist', 'Pricelist',
                                   default=lambda self: self.env['product.pricelist'].search([], limit=1).id,
                                   help='Pricelist of the selected partner.')
    invoice_id = fields.Many2one('account.invoice', 'Invoice', copy=False, readonly=True, track_visibility="onchange")
    partner_invoice_id = fields.Many2one('res.partner', 'Invoicing Address')
    address_id = fields.Many2one('res.partner', 'Delivery Address')
    invoiced = fields.Boolean('Invoiced', copy=False, readonly=True)
    paid = fields.Boolean('Paid', copy=False, track_visibility="onchange")
    company_id = fields.Many2one('res.company', 'Company',
                                 default=lambda self: self.env['res.company']._company_default_get('ti.service'))
    stage_id = fields.Many2one(comodel_name='ti.service.stage', string='Stage', group_expand='_read_group_stage_ids',
                            track_visibility='onchange', )
    state = fields.Selection([
        ('draft', 'New'),
        ('progress', 'In Progress'),
        ('done', 'Repaired')], string='Status',
        copy=False, default='draft', track_visibility='onchange',
        help="This is some help")
    user_id = fields.Many2one('res.users', string='Responsible', index=True, track_visibility='onchange',
                              default=lambda self: self.env.user)
    helpdesk_ticket_id = fields.Many2one(comodel_name='helpdesk.ticket', string='Helpdesk Ticket')

    time_call_received = fields.Datetime('Call Received', default=lambda self: fields.datetime.now())
    time_call_completed = fields.Datetime('Service End', default=lambda self: fields.datetime.now())
    time_call_attended = fields.Datetime('Service Start', default=lambda self: fields.datetime.now())
    date = fields.Datetime('Date', default=lambda self: fields.datetime.now())
    phone_no = fields.Char('Phone No.')

    # adding a signature field (binary)
    signature = fields.Binary(string='Signature')

    fault_description = fields.Text('Description of fault')

    @api.model
    def create(self, vals):
        if 'name' not in vals or vals['name'] == '':
            vals['name'] = self.env['ir.sequence'].next_by_code('ti.service') or _('New')
        return super(TiService, self).create(vals)

    @api.onchange('helpdesk_ticket_id')
    def _onchange_helpdesk_ticket_id(self):
        self.partner_id = self.helpdesk_ticket_id.partner_id

    @api.onchange('partner_id')
    def _on_change_partner_id(self):
        self.phone_no = self.partner_id.phone

    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        stage_ids = self.env['ti.service.stage'].search([])
        return stage_ids

    @api.onchange('partner_id')
    def onchange_partner_id(self):
        if not self.partner_id:
            self.address_id = False;
            self.partner_invoice_id = False;
            self.pricelist_id = self.env['product.pricelist'].search([], limit=1).id
        else:
            addresses = self.partner_id.address_get(['delivery', 'invoice', 'contact'])
            self.address_id = addresses['delivery'] or addresses['contact']
            self.partner_invoice_id = addresses['invoice']
            self.pricelist_id = self.partner_id.property_product_pricelist.id

    @api.multi
    def action_ti_service_invoice_create(self, group=False):
        """
            This is the function that will generated the invoice based on the charges
            that have been added to the Service Record
            @param group: It is set to true when group invoice is to be generated.
            @return: Invoice Ids.
        """
        res = dict.fromkeys(self.ids, False)
        invoices_group = {}
        InvoiceLine = self.env['account.invoice.line']
        Invoice = self.env['account.invoice']
        for service_record in self.filtered(lambda service_record: not service_record.invoice_id):
            # check if a partner is selected or the invoice address has been populated
            if not service_record.partner_id.id and not service_record.partner_invoice_id.id:
                raise UserError(_('You have to select a Partner Invoice Address in the Service Record Form!'))
            # @todo check this comment what is each meaning
            comment = "Some Comment"
            if group and service_record.partner_invoice_id.id in invoices_group:
                invoice = invoices_group[service_record.partner_invoice_id.id]
                invoice.write({
                    'name': invoice.name + ', ' + service_record.name,
                    'origin': invoice.origin + ', ' + service_record.name,
                    'comment': (comment and (invoice.comment and invoice.comment + "\n" + comment or comment)) or (
                        invoice.comment and invoice.comment or ''),
                })
            else:
                if not service_record.partner_id.property_account_receivable_id:
                    raise UserError(_('No account defined for partner "%s".') % service_record.partner_id.name)
                invoice = Invoice.create({
                    'name': service_record.name,
                    'origin': service_record.name,
                    'type': 'out_invoice',
                    'account_id': service_record.partner_id.property_account_receivable_id.id,
                    'partner_id': service_record.partner_invoice_id.id,# or repair.partner_id.id,
                    'currency_id': service_record.pricelist_id.currency_id.id,
                    'fiscal_position_id': service_record.partner_id.property_account_position_id.id
                })
                invoices_group[service_record.partner_invoice_id.id] = invoice
            service_record.write({'invoiced': True, 'invoice_id': invoice.id})
            for fee in service_record.fees_lines_ids.filtered(lambda fee: fee.to_invoice):
                if group:
                    name = service_record.name + "-" + fee.name
                else:
                    name = fee.name
                if not fee.product_id:
                    raise UserError(_('No product defined on Fees!'))

                if fee.product_id.property_account_income_id:
                    account_id = fee.product_id.property_account_income_id.id
                elif fee.product_id.categ_id.property_account_income_categ_id:
                    account_id = fee.product_id.categ_id.property_account_income_categ_id.id
                else:
                    raise UserError(_('No account defined for product "%s".') % fee.product_id.name)
                invoice_line = InvoiceLine.create({
                    'invoice_id': invoice.id,
                    'name': name,
                    'origin': service_record.name,
                    'account_id': account_id,
                    'quantity': fee.product_uom_qty,
                    'invoice_line_tax_ids': [(6, 0, [x.id for x in fee.tax_id])],
                    'uom_id': fee.product_uom.id,
                    'product_id': fee.product_id and fee.product_id.id or False,
                    'price_unit': fee.price_unit,
                    'price_subtotal': fee.product_uom_qty * fee.price_unit
                })
                fee.write({'invoiced': True, 'invoice_line_id': invoice_line.id})
            invoice.compute_taxes()
            res[service_record.id] = invoice.id
        return True
