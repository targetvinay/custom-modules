# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.addons import decimal_precision as dp #this is to add the dependency and use the decimal precision for roundings


class TiServiceFee(models.Model):
    _name = 'service.fee'
    _description = 'Service Fee'

    name = fields.Char('Description', index=True, required=True)
    service_id = fields.Many2one('ti.service', 'Service Reference',index=True, ondelete='cascade', required=True)
    product_id = fields.Many2one('product.product', 'Product')
    product_uom_qty = fields.Float('Quantity', digits=dp.get_precision('Product Unit of Measure'), required=True, default=1.0)
    price_unit = fields.Float('Unit Price', required=True)
    product_uom = fields.Many2one('product.uom', 'Product Unit of Measure', required=True)
    price_subtotal = fields.Float('Subtotal', compute='_compute_price_subtotal', digits=0)
    tax_id = fields.Many2many('account.tax', 'repair_fee_line_tax', 'repair_fee_line_id', 'tax_id', 'Taxes')
    invoice_line_id = fields.Many2one('account.invoice.line', 'Invoice Line', copy=False, readonly=True)
    to_invoice = fields.Boolean('To Invoice', default=True)
    invoiced = fields.Boolean('Invoiced', copy=False, readonly=True)

    @api.multi
    @api.depends('to_invoice', 'price_unit', 'service_id', 'product_uom_qty', 'product_id')
    def _compute_price_subtotal(self):
        """
            This function is calculating for every feed line the price_subtotal which 
            is the price without tax.
        """
        self.ensure_one()
        if not self.to_invoice:
            self.price_subtotal = 0.0
        else:
            taxes = self.tax_id.compute_all(self.price_unit, self.service_id.pricelist_id.currency_id, self.product_uom_qty, self.product_id, self.service_id.partner_id)
            self.price_subtotal = taxes['total_excluded']

    @api.onchange('service_id', 'product_id', 'product_uom_qty')
    def onchange_product_id(self):
        """ On change of product it sets product quantity, tax account, name,
        uom of product, unit price and price subtotal. """
        if not self.product_id or not self.product_uom_qty:
            return

        partner = self.service_id.partner_id
        pricelist = self.service_id.pricelist_id

        if partner and self.product_id:
            self.tax_id = partner.property_account_position_id.map_tax(self.product_id.taxes_id, self.product_id, partner).ids
        if self.product_id:
            self.name = self.product_id.display_name
            self.product_uom = self.product_id.uom_id.id

        warning = False
        if not pricelist:
            warning = {
                'title': _('No Pricelist!'),
                'message':
                    _('You have to select a pricelist in the Repair form !\n Please set one before choosing a product.')}
        else:
            price = pricelist.get_product_price(self.product_id, self.product_uom_qty, partner)
            if price is False:
                warning = {
                    'title': _('No valid pricelist line found !'),
                    'message':
                        _("Couldn't find a pricelist line matching this product and quantity.\nYou have to change either the product, the quantity or the pricelist.")}
            else:
                self.price_unit = price
        if warning:
            return {'warning': warning}