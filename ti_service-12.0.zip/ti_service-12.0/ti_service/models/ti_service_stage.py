# -*- coding: utf-8 -*-

from odoo import models, fields


class ti_service_stage(models.Model):
    _name = 'ti.service.stage'
    _description = 'Service Stage'
    
    name = fields.Char('Name')
