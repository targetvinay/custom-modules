# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class helpdesk_ticket(models.Model):
    _inherit = 'helpdesk.ticket'

    service_count = fields.Integer(compute='compute_service_count')

    @api.multi
    def compute_service_count(self):
        self.ensure_one()
        self.service_count = self.env['ti.service'].search_count([('helpdesk_ticket_id', '=', self.id)])

    def create_ti_service(self):
        return {
            'name': _('Create Service Order'),
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'ti.service',
            'context': {'default_helpdesk_ticket_id': self.id},
        }
