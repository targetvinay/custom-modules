# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import ti_service
from . import ti_service_fee
from . import helpdesk_ticket
from . import ti_service_stage
